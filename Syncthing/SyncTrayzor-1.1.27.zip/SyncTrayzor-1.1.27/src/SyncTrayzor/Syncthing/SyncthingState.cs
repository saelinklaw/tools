﻿namespace SyncTrayzor.Syncthing
{
    public enum SyncthingState
    {
        Stopped,
        Starting,
        Running,
        Stopping,
        Restarting
    }
}
