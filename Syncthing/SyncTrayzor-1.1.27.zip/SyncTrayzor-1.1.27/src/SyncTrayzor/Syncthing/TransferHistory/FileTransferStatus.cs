﻿namespace SyncTrayzor.Syncthing.TransferHistory
{
    public enum FileTransferStatus
    {
        Started,
        InProgress,
        Completed
    }
}
