﻿namespace SyncTrayzor.Design
{
    public class ViewModelLocator
    {
        public DummyFileTransfersTrayViewModel FileTransfersTrayViewModel => new DummyFileTransfersTrayViewModel();
    }
}
