﻿using System.Windows.Controls;

namespace SyncTrayzor.Pages.BarAlerts
{
    /// <summary>
    /// Interaction logic for PausedDevicesFromMeteringView.xaml
    /// </summary>
    public partial class PausedDevicesFromMeteringView : UserControl
    {
        public PausedDevicesFromMeteringView()
        {
            InitializeComponent();
        }
    }
}
