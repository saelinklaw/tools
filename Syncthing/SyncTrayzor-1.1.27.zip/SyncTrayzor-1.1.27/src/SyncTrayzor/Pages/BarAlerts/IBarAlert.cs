﻿namespace SyncTrayzor.Pages.BarAlerts
{
    public interface IBarAlert
    {
        AlertSeverity Severity { get; }
    }
}
