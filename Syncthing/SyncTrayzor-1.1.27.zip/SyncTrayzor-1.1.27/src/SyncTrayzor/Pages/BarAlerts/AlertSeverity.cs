﻿namespace SyncTrayzor.Pages.BarAlerts
{
    public enum AlertSeverity
    {
        Info,
        Warning,
    }
}
