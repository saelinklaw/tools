﻿namespace SyncTrayzor.Services.Config
{
    public enum SyncthingPriorityLevel
    {
        AboveNormal,
        BelowNormal,
        Idle,
        Normal,
    }
}
