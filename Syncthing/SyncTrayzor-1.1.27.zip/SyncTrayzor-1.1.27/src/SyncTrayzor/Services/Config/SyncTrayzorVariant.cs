﻿namespace SyncTrayzor.Services.Config
{
    public enum SyncTrayzorVariant
    {
        Installed,
        Portable
    }
}
