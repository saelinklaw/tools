﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SyncTrayzor.Services.Config
{
    public enum LogLevel
    {
        Info,
        Debug,
        Trace,
    }
}
