#define TYPE unsigned long
#define NAME strtoul
#include "strtox.c"
