/* pnggvrd.c was removed from libpng-1.2.20. */
