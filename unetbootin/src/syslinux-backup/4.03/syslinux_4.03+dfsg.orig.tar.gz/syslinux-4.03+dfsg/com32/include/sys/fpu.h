#ifndef _SYS_FPU_H
#define _SYS_FPU_H

extern int x86_init_fpu(void);

#endif /* _SYS_FPU_H */
