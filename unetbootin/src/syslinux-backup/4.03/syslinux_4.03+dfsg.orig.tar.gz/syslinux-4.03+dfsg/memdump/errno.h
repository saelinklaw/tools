#ifndef ERRNO_H
#define ERRNO_H

int errno;
void perror(const char *);

#endif /* ERRNO_H */
